'use strict';

const ZohoPeopleClient = require('./zohoPeopleClient');
const ZohoPeopleEnvironment = require('./zohoPeopleEnvironment');
const Logger = require('../../utils/logger');

class ZohoPeopleEmployeeService {
  constructor(client = null) {
    this.client = client || new ZohoPeopleClient();
  }

  async getEmployeeRawData(employeeId, context = null) {
    Logger.info(`Fetching employee raw data in real-time from Zoho People`, { employeeId });

    const token = context?.zohoToken ||
      process.env.ZOHO_PEOPLE_AUTH_TOKEN ||
      process.env.ZOHO_AUTH_TOKEN ||
      null;

    const dataCenter = context?.dataCenter || this.client.tenantConfig.dataCenter;
    const endpoints = ZohoPeopleEnvironment.getEndpoints(dataCenter);

    let rawRecord = null;
    let attendanceData = null;
    let leaveData = null;

    // Helper to unwrap Zoho People results
    const unwrapRecords = (res) => {
      if (!res) return [];
      if (Array.isArray(res)) return res;
      if (Array.isArray(res.response?.result)) return res.response.result;
      if (Array.isArray(res.result)) return res.result;
      if (res.response?.result && typeof res.response.result === 'object') {
        // Zoho sometimes returns indexed object {"0": {...}, "1": {...}}
        return Object.values(res.response.result).filter(v => v && typeof v === 'object');
      }
      if (typeof res === 'object' && (res.recordId || res.pkId || res.Employeename || res.EmailID)) {
        return [res];
      }
      return [];
    };

    const cleanId = String(employeeId || '').trim();
    const isNumericRecordId = /^\d+$/.test(cleanId);
    const isEmail = cleanId.includes('@');

    try {
      // 1. If employeeId is purely numeric, it is a Zoho internal recordId
      if (isNumericRecordId) {
        try {
          const byIdUrl = `${endpoints.employeeRecord}?recordId=${encodeURIComponent(cleanId)}`;
          const res = await this.client.request(byIdUrl, { token, dataCenter });
          const list = unwrapRecords(res);
          if (list.length > 0) {
            rawRecord = list[0];
          }
        } catch (byIdErr) {
          if (byIdErr.isAuthError) throw byIdErr;
          // Silent fallback to column searches if numeric recordId did not resolve
        }
      }

      // 2. If it is an email address, search by EmailID
      if (!rawRecord && isEmail) {
        try {
          const emailUrl = `${endpoints.employeeList}?searchColumn=EmailID&searchValue=${encodeURIComponent(cleanId)}`;
          const res = await this.client.request(emailUrl, { token, dataCenter });
          const list = unwrapRecords(res);
          if (list.length > 0) {
            rawRecord = list[0];
          }
        } catch (emailErr) {
          if (emailErr.isAuthError) throw emailErr;
        }
      }

      // 3. For alphanumeric codes (e.g. OWN01), search by EMPLOYEEID
      if (!rawRecord) {
        try {
          const searchUrl = `${endpoints.employeeList}?searchColumn=EMPLOYEEID&searchValue=${encodeURIComponent(cleanId)}`;
          const res = await this.client.request(searchUrl, { token, dataCenter });
          const list = unwrapRecords(res);
          if (list.length > 0) {
            rawRecord = list[0];
          }
        } catch (searchErr) {
          if (searchErr.isAuthError) throw searchErr;
        }
      }

      // 4. Try searching by EmployeeID (alternate casing in some Zoho People forms)
      if (!rawRecord) {
        try {
          const searchUrl = `${endpoints.employeeList}?searchColumn=EmployeeID&searchValue=${encodeURIComponent(cleanId)}`;
          const res = await this.client.request(searchUrl, { token, dataCenter });
          const list = unwrapRecords(res);
          if (list.length > 0) {
            rawRecord = list[0];
          }
        } catch (altErr) {
          if (altErr.isAuthError) throw altErr;
        }
      }

      // 5. Try fetching live records list and matching exact ID, email or name
      if (!rawRecord) {
        try {
          const allUrl = `${endpoints.employeeList}?limit=200`;
          const res = await this.client.request(allUrl, { token, dataCenter });
          const list = unwrapRecords(res);
          rawRecord = list.find(r => {
            const empNum = r.EMPLOYEEID || r.EmpId || r.EmployeeID || r['Employee ID'] || r.recordId || r.pkId;
            const email = r.EmailID || r.email || r['Email ID'];
            const name = r.Employeename || r.fullName || r['Employee Name'];
            return (
              (empNum && String(empNum).trim().toUpperCase() === cleanId.toUpperCase()) ||
              (email && String(email).trim().toLowerCase() === cleanId.toLowerCase()) ||
              (name && String(name).trim().toUpperCase() === cleanId.toUpperCase())
            );
          });
        } catch (allErr) {
          if (allErr.isAuthError) throw allErr;
        }
      }

      // If record found, also attempt real-time attendance and leave
      if (rawRecord) {
        const zohoEmpId = rawRecord.EMPLOYEEID || rawRecord.EmpId || employeeId;

        // Fetch real-time attendance
        try {
          const attUrl = `${endpoints.attendanceSummary}?empId=${encodeURIComponent(zohoEmpId)}`;
          const attRes = await this.client.request(attUrl, { token, dataCenter });
          attendanceData = attRes?.response?.result || attRes?.result || attRes;
        } catch (attErr) {
          Logger.info('Attendance real-time lookup skipped', { error: attErr.message });
        }

        // Fetch real-time leave
        try {
          const leaveUrl = `${endpoints.leaveBalances}?userId=${encodeURIComponent(zohoEmpId)}`;
          const leaveRes = await this.client.request(leaveUrl, { token, dataCenter });
          leaveData = leaveRes?.response?.result || leaveRes?.result || leaveRes;
        } catch (leaveErr) {
          Logger.info('Leave real-time lookup skipped', { error: leaveErr.message });
        }
      }
    } catch (err) {
      if (err.isAuthError) {
        return {
          source: 'zoho_people',
          employeeId,
          available: false,
          error: 'AUTH_REQUIRED',
          message: 'Zoho People authentication token is missing, invalid, or expired. Please configure a valid live Zoho People OAuth token.'
        };
      }

      Logger.warn(`Live Zoho People fetch error for ${employeeId}:`, { message: err.message });
      return {
        source: 'zoho_people',
        employeeId,
        available: false,
        error: 'CONNECTION_ERROR',
        message: `Failed to query Zoho People API: ${err.message}`
      };
    }

    if (!rawRecord) {
      return {
        source: 'zoho_people',
        employeeId,
        available: false,
        error: 'NOT_FOUND',
        message: `Employee "${employeeId}" not found in Zoho People. Please ensure the employee exists in your Zoho People portal.`
      };
    }

    return {
      source: 'zoho_people',
      employeeId,
      available: true,
      raw: rawRecord,
      attendance: attendanceData,
      leave: leaveData
    };
  }

  /**
   * Fetches the real-time list of all employees currently in Zoho People
   */
  async getLiveEmployeeDirectory(context = null) {
    const token = context?.zohoToken ||
      process.env.ZOHO_PEOPLE_AUTH_TOKEN ||
      process.env.ZOHO_AUTH_TOKEN ||
      null;

    const dataCenter = context?.dataCenter || this.client.tenantConfig.dataCenter;
    const endpoints = ZohoPeopleEnvironment.getEndpoints(dataCenter);

    const res = await this.client.request(`${endpoints.employeeList}?limit=200`, { token, dataCenter });
    const records = Array.isArray(res)
      ? res
      : (res?.response?.result || res?.result || (res?.response ? Object.values(res.response) : []));

    const flatList = Array.isArray(records) ? records : Object.values(records || {});

    return flatList
      .filter(r => r && typeof r === 'object')
      .map(r => ({
        recordId: r.recordId || r.pkId || null,
        employeeId: r.EMPLOYEEID || r.EmpId || r.EmployeeID || r['Employee ID'] || r.recordId || null,
        fullName: r.Employeename || r['Employee Name'] || `${r.FirstName || ''} ${r.LastName || ''}`.trim() || 'Unknown',
        jobTitle: r.Designation || r.designation || r['Designation'] || null,
        department: r.Department || r.department || r['Department'] || null,
        email: r.EmailID || r.email || r['Email ID'] || null,
        workLocation: r.LocationName || r.location || r['Location Name'] || null,
        status: r.EMPLOYEESTATUS || r.status || r['Employee Status'] || 'Active'
      }));
  }
}

module.exports = ZohoPeopleEmployeeService;
